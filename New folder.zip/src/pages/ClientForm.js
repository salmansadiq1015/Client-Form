import React, { useRef, useState } from "react";
import emailjs from "@emailjs/browser";
import "./../App.css";
import Verify from "../components/Verify";
// import { AiOutlineSchedule} from "react-icons/ai";
import { BiPhoneCall } from "react-icons/bi";
import { MdOutlineAlternateEmail } from "react-icons/md";
import { TfiWorld } from "react-icons/tfi";
import { AiOutlinePlus } from "react-icons/ai";
import { IoCloseCircleSharp } from "react-icons/io5";
import { toast } from "react-toastify";
import Bsignature from "../components/Bsignature";
// import axios from "axios";

export default function ClientForm() {
  const form = useRef();
  const [buyer, setBuyer] = useState("");
  const [seller, setSeller] = useState("");
  const [propertyAddress, setPropertyAddress] = useState("");
  const [purchasePrice, setPurchasePrice] = useState("");
  const [earnMoney, setEarnMoney] = useState("");
  const [cclosingDate, setCclosingDate] = useState("");
  const [financing, setFinancing] = useState("");
  // const [deligencePeriod, setDeligencePeriod] = useState("");
  const [other, setOther] = useState("");
  const [buyerPrient, setBuyerPrient] = useState("");
  const [sellerPrient, setSellerPrient] = useState("");
  const [buyerSignature, setBuyerSignature] = useState("");
  // const [sellerSignature, setSellerSignature] = useState("");
  const [bdate, setBdate] = useState("");
  const [sdate, setSdate] = useState("");
  const [logo, setLogo] = useState("");
  const [addClause, setAddClause] = useState("");
  // const [exclusive, setExclusive] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [noLogo, setNologo] = useState("No");
  //   -----------Show---------------------->
  const [bshow, setbShow] = useState(false);
  // const [Sshow, setSShow] = useState(false);
  const [varifyShow, setVarifyShow] = useState(false);
  // const [formShow, setFormShow] = useState(true);

  //   ---------|URL|---------------->
  const [burl, setBurl] = useState("");
  // const [surl, setSurl] = useState("");

  //   <-----------------------Validation--------------------->
  const handleForm = () => {
    if (
      !buyer ||
      !seller ||
      !propertyAddress ||
      !purchasePrice ||
      !earnMoney ||
      !cclosingDate ||
      !financing ||
      !email ||
      !other ||
      !sellerPrient ||
      !burl ||
      !phone ||
      !bdate ||
      !sdate
    ) {
      toast.success("Please Fill all fields!", {
        position: "top-center",
        theme: "dark",
      });
    } else {
      scrollToTop();
      setVarifyShow(true);
      // setFormShow(false);
    }
  };

  //   getURL
  const handleSignature = () => {
    setBurl(buyerSignature.getTrimmedCanvas().toDataURL("image/png"));
  };
  // const shandleSignature = () => {
  //   setSurl(sellerSignature.getTrimmedCanvas().toDataURL("image/png"));
  // };

  //   ------------------------->Get Logo Image----------------------->
  // const handleFileChange = (e) => {
  //   const file = e.target.files[0];

  //   if (file) {
  //     const reader = new FileReader();

  //     reader.onload = (event) => {
  //       setLogo(event.target.result);
  //     };

  //     reader.readAsDataURL(file);
  //   }
  // };

  const handleFileChange = (e) => {
    const file = e.target.files[0];

    if (file) {
      if (file.size > 50 * 1024) {
        // Check if the file size is greater than 50 KB (in bytes)
        toast.error("Logo size should be 25 KB or less.", {
          position: "top-center",
        });
        return; // Prevent further processing
      }

      const reader = new FileReader();

      reader.onload = (event) => {
        setLogo(event.target.result);
      };

      reader.readAsDataURL(file);
    }
  };

  // ---------------------------Form Submission------------------->

  const sendEmail = () => {
    // e.preventDefault();
    // const emailData = [form.current, logo, burl, Sshow];

    emailjs
      .sendForm(
        "service_cku0zsd",
        "template_f56c4nj",
        form.current,
        "1O8aDzb26QU7189Xy"
      )
      .then(
        (result) => {
          toast.success("Form has been submitted successfully!", {
            theme: "dark",
            position: "top-center",
          });
          setVarifyShow(false);
          scrollToTop();
          setTimeout(() => {
            window.location.reload();
          }, 4000);
          console.log(result.text);
        },
        (error) => {
          console.log(error.text);
          toast.success("Something went wrong!", {
            theme: "light",
            position: "top-center",
          });
        }
      );
  };

  //   -------------------------------Scroll------------------------------>
  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };

  const handlebSignature = () => {
    // scrollToTop();
    setbShow(true);
  };

  // const handleSSignature = () => {
  //   scrollToTop();
  //   setSShow(true);
  // };

  // --------------------SMTP Form Handeler------------------->
  // Handle Form
  // const sendEmail = () => {
  //   const config = {
  //     Username: "msalmansadiq121@gmail.com",
  //     Password: "15F61F608B63F33940996EBD825E5942621A",
  //     Host: "smtp.elasticemail.com",
  //     Port: 2525,
  //     To: "msalmansadiq121@gmail.com",
  //     From: "msalmansadiq1015@gmail.com",
  //     Subject: "This is my contact form",
  //     Body: `<h1 style={{color:"red"}}>Buyer: ${buyer} connected to your email</h1>
  //            <img src=${burl} alt="logoimage" /> `,
  //   };

  //   if (window.Email) {
  //     window.Email.send(config).then(() =>
  //       toast.success("Email send successfully!")
  //     );
  //   }
  // };

  // --------------------Handle Form Backend------------>
  // const formData = {
  //   buyer,
  //   seller,
  //   propertyAddress,
  //   // purchasePrice,
  //   // earnMoney,
  //   // cclosingDate,
  //   // financing,
  //   // deligencePeriod,
  //   // other,
  //   // buyerPrient,
  //   // sellerPrient,
  //   // burl,
  //   // bdate,
  //   // sdate,
  //   // logo,
  //   // exclusive,
  //   // addClause,
  // };

  // const sendEmail = async () => {

  //   try {
  //     const response = await axios.post(
  //       `http://localhost:5000/api/send-email`,
  //       formData
  //     );
  //     console.log("Email sent successfully!", response.data);
  //   } catch (error) {
  //     console.log(error);
  //   }
  // };

  return (
    <>
      <div className="from-container">
        <div className="form">
          {/* <div className="logo-main">
           <div className="logo-image">
             <img src="/logoimg.jpg" alt="header" />
           </div>
           <div className="logo-text">
             LRC Comercial, LRC | 133 N. 33rd Street, #33, Quincy, IL, 62301
           </div>
         </div> */}
          <div>
            <div className="social-icons" style={{ borderRadius: ".5rem" }}>
              <div className="first">
                <div>
                  <BiPhoneCall />
                </div>
                <div style={{ marginLeft: "3px" }}>+1 (217) 823-3110</div>
              </div>

              <div className="first">
                <div>
                  <MdOutlineAlternateEmail />
                </div>
                <div style={{ marginLeft: "3px" }}>
                  spencer@lrccomercial.com
                </div>
              </div>

              <div className="first">
                <div>
                  <TfiWorld />
                </div>
                <div style={{ marginLeft: "3px" }}>lrccomercial.com</div>
              </div>
            </div>
          </div>
          <div className="schedule">
            <a
              href="https://tidycal.com/schelp/loi"
              target="blank"
              style={{ textDecoration: "none" }}
              className="bookbtn"
            >
              {/* <AiOutlineSchedule className="schedule" /> */}
              Book Appointment
            </a>
          </div>

          <h1>LETTER OF INTENT TO PURCHASE REAL ESTATE</h1>
          <form ref={form} onSubmit={sendEmail}>
            <div className="inputBox">
              <input
                type="text"
                required
                name="buyer"
                value={buyer}
                onChange={(e) => setBuyer(e.target.value)}
              />
              <span>BUYER</span>
            </div>
            <div className="inputBox">
              <input
                type="text"
                required
                name="seller"
                value={seller}
                onChange={(e) => setSeller(e.target.value)}
              />
              <span>SELLER</span>
            </div>
            <p>
              This is a letter of intent only. It does not create a legally
              binding obligation on the parties or their brokers. This letter of
              intent is subject to agreement between the parties upon a formal
              written purchase and sale contract containing the terms and
              conditions the parties find acceptable. This letter of intent sets
              forth some of the general terms and conditions for a purchase and
              sale transaction to be entered into concerning the above described
              real property.
            </p>
            {/* --------------Logo-------------- */}
            <div
              style={{
                display: "flex",
                flexDirection: "column",
              }}
            >
              <div
                style={{
                  width: "14rem",
                  height: "10rem",
                  border: "2px dotted orangered",
                  overflow: "hidden",
                  Object: "fill",
                  borderRadius: ".3rem",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  position: "relative",
                }}
              >
                <input
                  type="file"
                  required
                  id="logo"
                  onChange={handleFileChange}
                  style={{ display: "none" }}
                />
                {logo ? (
                  <>
                    <img
                      src={logo}
                      value={logo}
                      alt="Selected Logo"
                      style={{ width: "100%", height: "100%" }}
                    />
                    <IoCloseCircleSharp
                      className="close"
                      onClick={() => setLogo("")}
                    />
                    <input
                      type="text"
                      style={{ display: "none" }}
                      name="logo"
                      value={logo}
                    />
                  </>
                ) : (
                  <label
                    htmlFor="logo"
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: ".5rem",
                    }}
                  >
                    <AiOutlinePlus className="logoIcon" size={25} />
                    Add Custom Logo
                  </label>
                )}
              </div>
              <label
                htmlFor="Nologo"
                style={{
                  fontSize: "1rem",
                  marginTop: "1.2rem",
                  fontWeight: "500",
                }}
              >
                <input
                  type="checkbox"
                  id="Nologo"
                  name="nologo"
                  value={noLogo}
                  onChange={(e) => setNologo(e.target.value)}
                  // onClick={() => setLogo("")}
                />{" "}
                No logo
              </label>
            </div>

            {/* --------------------Logo---------------- */}
            <div className="inputBox">
              <input
                type="text"
                required
                name="propertyAddress"
                value={propertyAddress}
                onChange={(e) => setPropertyAddress(e.target.value)}
              />
              <span>PROPERTY ADDRESS City, State, Zipcode</span>
            </div>
            <div className="inputBox">
              <input
                type="number"
                required
                name="purchasePrice"
                value={purchasePrice}
                onChange={(e) => setPurchasePrice(e.target.value)}
              />
              <span>PURCHASE PRICE (in USD with $)</span>
            </div>
            <div className="inputBox">
              <input
                type="number"
                required
                name="earnMoney"
                value={earnMoney}
                onChange={(e) => setEarnMoney(e.target.value)}
              />
              <span>EARNEST MONEY (in USD with $)</span>
            </div>
            <div className="inputBox">
              <label
                htmlFor="closingDate"
                style={{
                  fontSize: ".9rem",
                  fontWeight: "400",
                  color: "#777",
                }}
                className="closing-label"
              >
                CONTRACT CLOSING DATE
              </label>

              <input
                type="date"
                id="closingDate"
                required
                name="cclosingDate"
                value={cclosingDate}
                onChange={(e) => setCclosingDate(e.target.value)}
              />
              <span className="closing-Date">CONTRACT CLOSING DATE</span>
            </div>
            {/* // ---------Finance---------- */}
            {/* <div className="inputBox">
           <input
             type="text"
             required
             name="financing"
             value={financing}
             onChange={(e) => setFinancing(e.target.value)}
           />
           <span>FINANCING</span>
         </div> */}

            <div
              className="inputBox selectbox"
              // style={{
              //   border: "2px solid #444",
              //   padding: ".5rem .7rem",
              //   borderRadius: ".3rem",
              //   width: "12rem",
              //   marginTop: "1rem",
              // }}
            >
              <span
                style={{
                  fontSize: ".9rem",
                  color: "#777",
                  marginTop: "-2.4rem",
                  marginLeft: "-.6rem",
                }}
              >
                FINANCING Period
              </span>
              <select
                required
                name="financing"
                value={financing}
                onChange={(e) => setFinancing(e.target.value)}
                style={{
                  border: "none",
                  outline: "none",
                  fontSize: "1.1rem",
                  fontWeight: "500",
                  background: "transparent",
                }}
              >
                <option value="">Select Financing </option>
                <option value="45 Days">45 Days</option>
                <option value="60 Days">60 Days</option>
                <option value="90 Days">90 Days</option>
              </select>
            </div>

            {/* <div className="inputBox">
             <input
               type="text"
               required
               name="deligencePeriod"
               value={deligencePeriod}
               onChange={(e) => setDeligencePeriod(e.target.value)}
             />
             <span> DUE DILIGENCE PERIOD</span>
           </div> */}
            <div className="inputBox">
              <input
                type="text"
                required
                name="addClause"
                value={addClause}
                onChange={(e) => setAddClause(e.target.value)}
              />
              <span> ADDITIONAL CLAUSES</span>
            </div>
            {/* <div className="inputBox">
             <input
               type="text"
               required
               name="exclusive"
               value={exclusive}
               onChange={(e) => setExclusive(e.target.value)}
             />
             <span> EXCLUSIVITY</span>
           </div> */}
            {/* ---------------- */}
            <div className="inputBox">
              <input
                type="text"
                required
                name="other"
                value={other}
                onChange={(e) => setOther(e.target.value)}
              />
              <span> Insert any deal specific clause etc here</span>
            </div>
            {/* <div className="inputBox">
           <input
             type="text"
             required
             name="footer"
             value={footer}
             onChange={(e) => setFooter(e.target.value)}
           />
           <span> Footer</span>
         </div> */}
            {/* ------------------------ */}
            <div className="prints">
              <div className="inputBox">
                <input
                  type="text"
                  required
                  name="buyerPrient"
                  value={buyerPrient}
                  onChange={(e) => setBuyerPrient(e.target.value)}
                />
                <span> Buyer Print</span>
              </div>
              <div className="inputBox">
                <input
                  type="text"
                  required
                  name="sellerPrient"
                  value={sellerPrient}
                  onChange={(e) => setSellerPrient(e.target.value)}
                />
                <span> Seller Print</span>
              </div>
            </div>

            <div
              className="prints"
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
              }}
            >
              {bshow ? (
                <>
                  <Bsignature
                    setBuyerSignature={setBuyerSignature}
                    buyerSignature={buyerSignature}
                    setbShow={setbShow}
                    handleSignature={handleSignature}
                  />
                </>
              ) : (
                ""
              )}
              {burl ? (
                <div className="urlimage" style={{ position: "relative" }}>
                  <img src={burl} alt="..." value={burl} className="imageURL" />
                  <IoCloseCircleSharp
                    className="close"
                    onClick={() => setBurl("")}
                  />
                  <input
                    type="text"
                    style={{ display: "none" }}
                    name="burl"
                    value={burl}
                  />
                  <button type="button" onClick={handlebSignature}>
                    Buyer Signature
                  </button>
                </div>
              ) : (
                <button type="button" onClick={handlebSignature}>
                  Buyer Signature
                </button>
              )}
            </div>

            <div
              className="prints"
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
              }}
            >
              <div className="inputBox">
                <input
                  type="date"
                  required
                  name="bdate"
                  value={bdate}
                  onChange={(e) => setBdate(e.target.value)}
                  className="sdate"
                />
                {/* <span> Date </span> */}
              </div>
              <div className="inputBox">
                <input
                  type="date"
                  required
                  name="sdate"
                  value={sdate}
                  onChange={(e) => setSdate(e.target.value)}
                  className="sdate"
                />
                {/* <span> Date </span> */}
              </div>
            </div>

            <div
              className="prints"
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
              }}
            >
              <div className="inputBox">
                <input
                  type="email"
                  required
                  name="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="sdate"
                />
                <span> Your Email </span>
              </div>
              <div className="inputBox">
                <input
                  type="number"
                  required
                  name="phone"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="sdate"
                />
                <span>Your Phone </span>
              </div>
            </div>

            {/* ---------------- */}
            <div className="fbutton">
              <button
                type="button"
                onClick={handleForm}
                className="scroll-to-top-button"
              >
                Verify Information
              </button>
              {/* <button
                type="submit"
                onClick={sendEmail}
                className="scroll-to-top-button"
                style={{ background: "green" }}
              >
                Submit
              </button> */}
            </div>
          </form>
        </div>

        {/* -----------------Varification Form-------------- */}
        <>
          {varifyShow && (
            <Verify
              setVarifyShow={setVarifyShow}
              buyer={buyer}
              seller={seller}
              propertyAddress={propertyAddress}
              purchasePrice={purchasePrice}
              earnMoney={earnMoney}
              cclosingDate={cclosingDate}
              financing={financing}
              // deligencePeriod={deligencePeriod}
              other={other}
              buyerPrient={buyerPrient}
              sellerPrient={sellerPrient}
              buyerSignature={burl}
              // sellerSignature={surl}
              bdate={bdate}
              sdate={sdate}
              logo={logo}
              // footer={footer}
              // exclusive={exclusive}
              addClause={addClause}
              email={email}
              phone={phone}
              nologo={noLogo}
              sendEmail={sendEmail}
              // setFormShow={setFormShow}
            />
          )}
        </>
      </div>
    </>
  );
}
