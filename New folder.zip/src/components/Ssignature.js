import React from "react";
import "./style.css";
import SignatureCanvas from "react-signature-canvas";
import { IoCloseCircle } from "react-icons/io5";

export default function Ssignature({
  setSellerSignature,
  sellerSignature,
  setSShow,
  shandleSignature,
}) {
  const handleClear = () => {
    sellerSignature.clear();
  };

  //   Handle Signature
  const handleSignature = () => {
    shandleSignature();
    setSShow(false);
  };
  return (
    <div className="buyerSignature">
      <div className="sig-box" style={{ position: "relative" }}>
        <IoCloseCircle onClick={() => setSShow(false)} />
        <h3 style={{ color: "#fff", textShadow: "-1px 1px 0px #000" }}>
          Buyer Signature
        </h3>
        <SignatureCanvas
          ref={(data) => setSellerSignature(data)}
          canvasProps={{ className: "sigCanvas" }}
          value={sellerSignature}
          onChange={(e) => setSellerSignature(e.target.value)}
        />
        <div className="buttons" style={{ display: "flex", gap: "2rem" }}>
          <input
            type="button"
            style={{ width: "5rem" }}
            onClick={handleClear}
            value="Clear"
          />

          <input
            type="button"
            style={{ width: "5rem" }}
            onClick={handleSignature}
            value="Save"
          />
        </div>
      </div>
    </div>
  );
}
