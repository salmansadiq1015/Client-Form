import React from "react";

export default function Date() {
  const formatDate = (inputDate) => {
    // Parse the input date
    const parsedDate = new Date(inputDate);

    // Create arrays for month and month names
    const months = [
      "JANUARY",
      "FEBRUARY",
      "MARCH",
      "APRIL",
      "MAY",
      "JUNE",
      "JULY",
      "AUGUST",
      "SEPTEMBER",
      "OCTOBER",
      "NOVEMBER",
      "DECEMBER",
    ];

    // Format the date
    const day = parsedDate.getDate();
    const month = months[parsedDate.getMonth()];
    const year = parsedDate.getFullYear();

    return `${day} ${month}, ${year}`;
  };

  const inputDate = "2023-09-12";
  const formattedDate = formatDate(inputDate);

  return (
    <div>
      <p>Input Date: {inputDate}</p>
      <p>Formatted Date: {formattedDate}</p>
    </div>
  );
}
